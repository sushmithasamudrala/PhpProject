<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include '../includes/common.php';

$email=$_POST['email'];
$pattern_email="/^[_a-z0-9-]+*@[a-z0-9-]+(\.[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z][2,3])$/";

$password=$_POST['password'];

$name = mysqli_escape_string($con,filter_input(INPUT_POST,'name'));
$email1=  mysqli_real_escape_string($con, $email);
$password1= mysqli_escape_string($con, $password);
$contact = mysqli_escape_string($con, filter_input(INPUT_POST,'contact'));
$city = mysqli_escape_string($con, filter_input(INPUT_POST,'city'));
$address = mysqli_escape_string($con, filter_input(INPUT_POST,'address'));
$select_query="SELECT id FROM users WHERE email = '$email'";
$select_query_result=  mysqli_query($con, $select_query) or die(mysqli_error($con));
$no_rows=  mysqli_num_rows($select_query_result);
if($no_rows != 0){
    echo 'Email exists';
    header('location:signup.php');
}
else{
   $insert_query= "INSERT into users (name,email,password,contact,city,address) values ('$name','$email','$password','$contact','$city','$address')";
   $insert_query_result=  mysqli_query($con, $insert_query) or die(mysqli_error($con));
   $id=mysqli_insert_id($con);
   $_SESSION['id']=$id;
   $_SESSION['email']=$email;
   header('location:products.php');
}