<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LifeStyle Store</title>
   <link rel="stylesheet" href="../css/cart.css" type="text/css"/>
     </head> 
    <body>
      <?php
      session_start();
        include '../includes/common.php';
        include '../includes/header.php';
      ?>
        
        <br><br>
<div class="container_table">
            
  <table class="table table-striped">
     
                <tr><th>Item Number</th><th>Item Name</th><th>Price</th><th></th></tr>
                <?php
                $id=$_SESSION['id'];
                $arry_query="SELECT * FROM users_items INNER JOIN users ON users_items.user_id=users.id WHERE users.id=$id";
                $arry_query_result= mysqli_query($con, $arry_query) or die(mysqli_error($con));
                $no_rows= mysqli_num_rows($arry_query_result);
                $sum=0;
                if($no_rows==0){
                    echo '<tr><td><h5 class="text-danger text1"><b>Add items to cart first!</b></h5></td><td></td><td></td><td></td></tr>';
                }
                else{
                    while($rows=mysqli_fetch_array($arry_query_result)){
                       $pro_query="SELECT * FROM items WHERE items.id=$rows[2]";
                        $pro_result= mysqli_query($con,$pro_query) or die(mysqli_error($con));
                        $pro= mysqli_fetch_array($pro_result);
                        echo '<tr><td>'.$rows[2].'<td>'.$pro[1].'</td><td>Rs '.$pro[2].'/-</td><td><a href="cart-remove.php?id='.$rows[2].'" class="remove_item_link">Remove from Cart</a></td>';
                        $sum=$sum+$pro[2];
                }
                  
                }
                ?>
                 
               <?php echo'<tr><td></td><td>Total</td><td>Rs '.$sum.'/-</td><td><a href=success.php?id='.$id.' class="btn btn-primary">Confirm Order</a></td></tr>';?>
          


  </table>
    <div>
             <?php
             ?>
    </div>
</div>
   
         <?php
       include '../includes/footer.php';
         ?>
    </body>
</html>
