<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();

include '../includes/common.php';
$item_id=$_GET['id'];
$user_id=$_SESSION['id'];
$delete_query="DELETE FROM users_items WHERE user_id=$user_id AND item_id=$item_id";
$delete_query_result=mysqli_query($con,$delete_query) or die(mysqli_error($con));
header("location:cart.php");