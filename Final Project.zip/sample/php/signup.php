<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LifeStyle Store</title>
   <link rel="stylesheet" href="../css/signup.css" type="text/css"/>
     </head> 
    <body>
        <?php
        include '../includes/header.php';
        ?>
        <br><br><br>
        <h2 align ="center"><strong>SIGNUP</strong></h2>
       
     <div class="container_body">
    <div class="row">
      <div class="col-md-5">
          <form method="POST" action="signup_script.php">
              <div class="panel-body">
                         <div class="col-sm-12">
                  <div class="form-group">
                  <input type="text" class="form-control" id="inputName3"
                         placeholder="Name" name="name"/>
                 </div>
             </div>
      <div class="col-sm-12">
        <div class="form-group">
                  <input type="email" class="form-control" id="inputEmail3"
                    placeholder="Email" name ="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"/>
                 </div>
             </div>
         
              <div class="col-sm-12">
                 <div class="form-group">
                  <input type="password" class="form-control" id="inputPassword3"
                    placeholder="Password" name="password" required  pattern=".{8,}"/>
                </div>
             </div>
              <div class="col-sm-12">
        <div class="form-group">
                  <input type="number" class="form-control" id="inputContact3"
                    placeholder="Contact" name="contact"/>
                 </div>
             </div>
             
             <div class="col-sm-12">
        <div class="form-group">
                  <input type="text" class="form-control" id="inputCity3"
                         placeholder="City" name="city" maxlength="10"/>
                 </div>
             </div>
              <div class="col-sm-12">
        <div class="form-group">
                  <input type="text" class="form-control" id="inputAddress3"
                    placeholder="Address" name="address"/>
                 </div>
             </div>
                  <div class="col-sm-12">   
         <button class="btn btn-primary">Submit</button>
                 
                 
         </div>
             </div>
          </form>
        </div>
      </div>
    </div>
     <?php
     include '../includes/footer.php';
     ?>
    </body>
</html>
         
       