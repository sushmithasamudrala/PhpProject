<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
include '../includes/common.php';
if (!isset($_SESSION["email"])) {
     header('location:index.php');
 }

$id = $_SESSION['id'];
$password=  (mysqli_real_escape_string($con, filter_input(INPUT_POST,'password')));
$newpassword =(mysqli_escape_string($con,filter_input(INPUT_POST,'newpassword')));
$confirmpassword =(mysqli_escape_string($con,filter_input(INPUT_POST,'confirmpassword')));
 
 //$select_query="SELECT * FROM users WHERE password ='$password'";
 //$select_query_result=  mysqli_query($con, $select_query) or die(mysqli_error($con));
 
 if($newpassword == $confirmpassword)
    {
      $select_query = "UPDATE users SET password='$newpassword' WHERE id='$id'";
      $select_query_result=  mysqli_query($con, $select_query) or die(mysqli_error($con));
      header('location:products.php');
    }
    else{
       
        die ("New password dont match!");
        header('location:settings.php');
    }
