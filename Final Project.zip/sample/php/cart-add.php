<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();


include '../includes/common.php';
$id=$_SESSION['id'];
$item_id=$_GET['id'];
$insert_query="INSERT INTO users_items(user_id,item_id,Status) values ('$id','$item_id','Added to cart')";
$insert_query_result= mysqli_query($con, $insert_query) or die(mysqli_error($con));
header("location:products.php");