<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

session_start();

require '../includes/common.php';

$email=  mysqli_real_escape_string($con, filter_input(INPUT_POST,'email'));
$password=  mysqli_real_escape_string($con, filter_input(INPUT_POST,'password'));
$select_query="SELECT * FROM users WHERE email = '$email' AND password ='$password'";
$select_query_result=  mysqli_query($con, $select_query) or die(mysqli_error($con));
$no_rows=mysqli_num_rows($select_query_result);

if($no_rows==0){
 
    header('location:login.php');
}
else{
     $row= mysqli_fetch_array($select_query_result);
    $_SESSION['id']=$row[0];
    $_SESSION['email']=$row[1];
    header('location:products.php');
}
