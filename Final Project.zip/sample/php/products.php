<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!--jQuery library--> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LifeStyle Store</title>
  
<link rel="stylesheet" href="../css/products.css" type="text/css"/>
    </head> 
     
         
      <body>
        <?php
         session_start();
          include '../includes/common.php';
          include '../includes/header.php';
          include '../includes/check-if-added.php';
        ?>
          <br><br><br>
        <div class="container">
            <div class="jumbotron">
                <h1>Welcome to our Lifestyle Store!</h1>
                <p>We have the best cameras, watches and smartphones for you. No need to hunt around, we have all in one place.</p>
            </div>
        </div>
        <div class="row row_style text-center">
            <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/canon1.jpg" alt="camera">
                    <div class="caption">
                        <h3>Cannon EOS</h3>
              
                <p>Price: 36,000.00</p>
             <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                  
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" ><button class="btn btn-block btn-success" disabled>Added to cart</button></a>';
                             } else { 
                                 ?>
         <a href="cart-add.php?id=1" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
             
       
                     <?php
                     }
                  }
                ?> 
                    </div>
            </div>
            </div>
                 <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/sony dslr 1.png" alt="camera">
                    <div class="caption">
                        <h3>SONY DSLR</h3>
                        <p>Price: 40,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                         echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=2" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                  </div>
            </div>
            
        </div>
                <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/sony1.jpg" alt="camera">
                    <div class="caption">
                        <h3>SONY DSLR 2</h3>
                        <p>Price: 48,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=3" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                  </div>
            </div>
            
        </div>
            <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/oly1.png" alt="camera">
                    <div class="caption">
                        <h3>Olympus</h3>
                        <p>Price: 80,000.00</p>
                       <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=4" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
        </div>
        
         <div class="row row_style text-center">
            <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/titan2.png" alt="titanwatch">
                    <div class="caption">
                        <h3>Titan #301</h3>
                        <p>Price: 10,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=5" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            </div>
                 <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/fossil1.jpg" alt="fossilwatch">
                    <div class="caption">
                        <h3>Fossil</h3>
                        <p>Price: 18,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=6" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
                <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/fast1.png" alt="fastrack">
                    <div class="caption">
                        <h3>Fastrack</h3>
                        <p>Price: 12,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=7" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
             
             <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/rolex.png" alt="rolex">
                    <div class="caption">
                        <h3>Rolex</h3>
                        <p>Price: 25,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=8" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
        </div>
        
         <div class="row row_style text-center">
            <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/i phone.png" alt="iphone">
                    <div class="caption">
                        <h3>I Phone 6s</h3>
                        <p>Price: 49,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=9" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            </div>
                 <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/honor.jpg" alt="honor">
                    <div class="caption">
                        <h3>Honor</h3>
                        <p>Price: 19,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=10" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
                <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/samsumg.png" alt="samsung">
                    <div class="caption">
                        <h3>Samsung Edge</h3>
                        <p>Price: 37,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=11" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
             
             <div class=" col-md-3 col-sm-6">
                <div class="thumbnail">
                    <img src="../Images/motog.png" alt="moto">
                    <div class="caption">
                        <h3>Moto G</h3>
                        <p>Price: 21,000.00</p>
                        <?php if (!isset($_SESSION['email'])) {
                      ?>
                <p><a href="login.php" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                   <?php
                     } else {
                           //We have created a function to check whether this particular product is added to cart or not.
                     if (check_if_added_to_cart(1)) 
                          { //This is same as if(check_if_added_to_cart != 0)
                             echo '<a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>';
                             } else { 
                                 ?>
                 <a href="cart-add.php?id=12" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                     <?php
                     }
                  }
                ?> 
                </div>
            </div>
            
        </div>
        </div>
        
          <?php
        include '../includes/footer.php';
          ?>
    </body>
</html>
