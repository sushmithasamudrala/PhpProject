<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();

include '../includes/common.php';



//if (!isset($_SESSION["email"])) {
     //header('location:index.php');
// }

$id=$_SESSION['id'];
$itemid =$_SESSION['id'];

$insert_query = "INSERT INTO users_items(user_id, item_id, status) VALUES('$id', '$itemid', 'Confirmed')" ;
$insert_query_result  = mysqli_query($con, $insert_query) or die(mysqli_error($con));
echo '<h4>Your order is confirmed. Thank you for shopping with us. <a href ="products.php">Click here</a> to purchase any other item.</h4> ';


