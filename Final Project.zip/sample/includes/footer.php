<div class="footer">
<div class="container">
        <center>
            <p>Copyright &copy; Lifestyle Store. All Rights Reserved  |  Contact Us: +91 90000 00000</p>
        </center>
        </div>
    </div>
