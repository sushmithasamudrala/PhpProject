<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//$id = $_SESSION['id'];
//$itemid = $_GET['id'];
function check_if_added_to_cart($item_id) {
    include '../includes/common.php';
    
$id = $_SESSION['id'];
//$item_id = $_GET['id'];
    
     $id=mysqli_insert_id($con);
    $select_query="SELECT * FROM users_items WHERE item_id='$item_id' AND user_id ='$id' and status='Added to cart'";
    $select_query_result=  mysqli_query($con, $select_query) or die(mysqli_error($con));
     $no_rows=  mysqli_num_rows($select_query_result);
     if($no_rows >= 1) {
         return 1;
         
     }
    else {
      return 0;
   }
}     